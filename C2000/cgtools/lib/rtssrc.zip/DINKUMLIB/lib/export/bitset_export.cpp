// EXPORTED FUNCTIONS
#include <bitset>
_STD_BEGIN

template<size_t _Bits>
	bitset<_Bits>::bitset(unsigned long _Val)
	{	// construct from bits in unsigned long
	_Tidy();
	for (size_t _Pos = 0; _Val != 0 && _Pos < _Bits; _Val >>= 1, ++_Pos)
		if (_Val & 1)
			set(_Pos);
	}

template<size_t _Bits>
	template<class _Elem,
	class _Tr,
	class _Alloc>
	void bitset<_Bits>::_Construct(
		const basic_string<_Elem, _Tr, _Alloc>& _Str,
		_BITSET_SIZE_TYPE _Pos,
		_BITSET_SIZE_TYPE _Count)
	{	// initialize from [_Pos, _Pos + _Count) elements in string
	typename basic_string<_Elem, _Tr, _Alloc>::size_type _Num;
	if (_Str.size() < _Pos)
		_Xran();	// _Pos off end
	if (_Str.size() - _Pos < _Count)
		_Count = _Str.size() - _Pos;	// trim _Count to size
	if (_Bits < _Count)
		_Count = _Bits;	// trim _Count to length of bitset
	_Tidy();

	for (_Pos += _Count, _Num = 0; _Num < _Count; ++_Num)
		if (_Str[--_Pos] == '1')
			set(_Num);
		else if (_Str[_Pos] != '0')
			_Xinv();
	}

template<size_t _Bits>
	bitset<_Bits>& bitset<_Bits>::operator<<=(size_t _Pos)
	{	// shift left by _Pos
	const int _Wordshift = _Pos / _Bitsperword;
	if (_Wordshift != 0)
		for (int _Wpos = _Words; 0 <= _Wpos; --_Wpos)	// shift by words
			_Array[_Wpos] = _Wordshift <= _Wpos
				? _Array[_Wpos - _Wordshift] : (_Ty)0;

	if ((_Pos %= _Bitsperword) != 0)
		{	// 0 < _Pos < _Bitsperword, shift by bits
		for (int _Wpos = _Words; 0 < _Wpos; --_Wpos)
			_Array[_Wpos] = (_Ty)((_Array[_Wpos] << _Pos)
				| (_Array[_Wpos - 1] >> (_Bitsperword - _Pos)));
		_Array[0] <<= _Pos;
		_Trim();
		}
	return (*this);
	}

template<size_t _Bits>
	bitset<_Bits>& bitset<_Bits>::operator>>=(size_t _Pos)
	{	// shift right by _Pos
	const int _Wordshift = _Pos / _Bitsperword;
	if (_Wordshift != 0)
		for (int _Wpos = 0; _Wpos <= _Words; ++_Wpos)	// shift by words
			_Array[_Wpos] = _Wordshift <= _Words - _Wpos
					? _Array[_Wpos + _Wordshift] : (_Ty)0;

	if ((_Pos %= _Bitsperword) != 0)
		{	// 0 < _Pos < _Bitsperword, shift by bits
		for (int _Wpos = 0; _Wpos < _Words; ++_Wpos)
			_Array[_Wpos] = (_Ty)((_Array[_Wpos] >> _Pos)
				| (_Array[_Wpos + 1] << (_Bitsperword - _Pos)));
		_Array[_Words] >>= _Pos;
		}
	return (*this);
	}

template<size_t _Bits>
	bitset<_Bits>& bitset<_Bits>::set(size_t _Pos,
	bool _Val)
	{	// set bit at _Pos to _Val
	if (_Bits <= _Pos)
		_Xran();	// _Pos off end
	if (_Val)
		_Array[_Pos / _Bitsperword] |= (_Ty)1 << _Pos % _Bitsperword;
	else
		_Array[_Pos / _Bitsperword] &= ~((_Ty)1 << _Pos % _Bitsperword);
	return (*this);
	}

template<size_t _Bits>
	bitset<_Bits>& bitset<_Bits>::flip()
	{	// flip all bits
	for (int _Wpos = _Words; 0 <= _Wpos; --_Wpos)
		_Array[_Wpos] = (_Ty)~_Array[_Wpos];

	_Trim();
	return (*this);
	}

template<size_t _Bits>
	unsigned long bitset<_Bits>::to_ulong() const
	{	// convert bitset to unsigned long
	enum
		{	// cause zero divide if unsigned long not multiple of _Ty
		_Assertion = 1
			/ (int)(sizeof (unsigned long) % sizeof (_Ty) == 0)};

	int _Wpos = _Words;
	for (; sizeof (unsigned long) / sizeof (_Ty) <= _Wpos; --_Wpos)
		if (_Array[_Wpos] != 0)
			_Xoflo();	// fail if any high-order words are nonzero

	unsigned long _Val = _Array[_Wpos];
	for (; 0 <= --_Wpos; )
		_Val = _Val << _Bitsperword | _Array[_Wpos];
	return (_Val);
		}

template<size_t _Bits>
	template<class _Elem,
	class _Tr,
	class _Alloc>
	basic_string<_Elem, _Tr, _Alloc> bitset<_Bits>::to_string() const
	{	// convert bitset to string
	basic_string<_Elem, _Tr, _Alloc> _Str;
	typename basic_string<_Elem, _Tr, _Alloc>::size_type _Pos;
	_Str.reserve(_Bits);

	for (_Pos = _Bits; 0 < _Pos; )
		_Str += (char)('0' + (int)test(--_Pos));
	return (_Str);
	}

template<size_t _Bits>
	size_t bitset<_Bits>::count() const
	{	// count number of set bits
	static char _Bitsperhex[] = "\0\1\1\2\1\2\2\3\1\2\2\3\2\3\3\4";
	size_t _Val = 0;
	for (int _Wpos = _Words; 0 <= _Wpos; --_Wpos)
		for (_Ty _Wordval = _Array[_Wpos]; _Wordval != 0; _Wordval >>= 4)
			_Val += _Bitsperhex[_Wordval & 0xF];
	return (_Val);
	}

template<size_t _Bits>
	bool bitset<_Bits>::operator==(const bitset<_Bits>& _Right) const
	{	// test for bitset equality
	for (int _Wpos = _Words; 0 <= _Wpos; --_Wpos)
		if (_Array[_Wpos] != _Right._Getword(_Wpos))
			return (false);
	return (true);
	}

template<size_t _Bits>
	bool bitset<_Bits>::any() const
	{	// test if any bits are set
	for (int _Wpos = _Words; 0 <= _Wpos; --_Wpos)
		if (_Array[_Wpos] != 0)
			return (true);
	return (false);
	}

template<size_t _Bits>
	void bitset<_Bits>::_Tidy(_Ty _Wordval)
	{	// set all words to _Wordval
	for (int _Wpos = _Words; 0 <= _Wpos; --_Wpos)
		_Array[_Wpos] = _Wordval;
	if (_Wordval != 0)
		_Trim();
	}

template<class _Elem,
	class _Tr,
	size_t _Bits>
	basic_istream<_Elem, _Tr>& operator>>(
		basic_istream<_Elem, _Tr>& _Istr, bitset<_Bits>& _Right)
	{	// extract bitset as a string
	const ctype<_Elem>& _Ctype_fac = use_facet< ctype<_Elem> >(_Istr.getloc());
	const _Elem _E0 = _Ctype_fac.widen('0');
	ios_base::iostate _State = ios_base::goodbit;
	bool _Changed = false;
	string _Str;
	const typename basic_istream<_Elem, _Tr>::sentry _Ok(_Istr);

	if (_Ok)
		{	// valid stream, extract elements
		_TRY_IO_BEGIN
		typename _Tr::int_type _Meta = _Istr.rdbuf()->sgetc();
		for (size_t _Count = _Right.size(); 0 < _Count;
			_Meta = _Istr.rdbuf()->snextc(), --_Count)
			{	// test _Meta
			_Elem _Char;
			if (_Tr::eq_int_type(_Tr::eof(), _Meta))
				{	// end of file, quit
				_State |= ios_base::eofbit;
				break;
				}
			else if ((_Char = _Tr::to_char_type(_Meta))
				!= _E0 && _Char != _E0 + 1)
				break;	// invalid element
			else if (_Str.max_size() <= _Str.size())
				{	// no room in string, give up (unlikely)
				_State |= ios_base::failbit;
				break;
				}
			else
				_Str.append(1, (_Char - _E0) + '0'), _Changed = true;
			}
		_CATCH_IO_(_Istr)
		}

	if (!_Changed)
		_State |= ios_base::failbit;
	_Istr.setstate(_State);
	_Right = bitset<_Bits>(_Str);	// convert string and store
	return (_Istr);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
