// EXPORTED FUNCTIONS
#include <fstream>
_STD_BEGIN

template<class _Elem, class _Traits>
	basic_filebuf<_Elem, _Traits> * basic_filebuf<_Elem, _Traits>::open(const char *_Filename,
	ios_base::openmode _Mode,
	int _Prot)
	{	// open a C stream with specified mode
	_Filet *_File;
	if (_Myfile != 0 || (_File = _Fiopen(_Filename, _Mode, _Prot)) == 0)
		return (0);	// open failed

	_Init(_File, _Openfl);
	_Initcvt((_Cvt *)&_USE(_Mysb::getloc(), _Cvt));
	return (this);	// open succeeded
	}

template<class _Elem, class _Traits>
	basic_filebuf<_Elem, _Traits> * basic_filebuf<_Elem, _Traits>::open(const wchar_t *_Filename,
	ios_base::openmode _Mode,
	int _Prot)
	{	// open a wide-named C stream -- EXTENSION
	_Filet *_File;
	if (_Myfile != 0 || (_File = _Fiopen(_Filename, _Mode, _Prot)) == 0)
		return (0);	// open failed

	_Init(_File, _Openfl);
	_Initcvt((_Cvt *)&_USE(_Mysb::getloc(), _Cvt));
	return (this);	// open succeeded
	}

template<class _Elem, class _Traits>
	basic_filebuf<_Elem, _Traits> * basic_filebuf<_Elem, _Traits>::close()
	{	// close the C stream
	_Myt *_Ans = this;
	if (_Myfile == 0)
		_Ans = 0;
	else
		{	// put any homing sequence and close file
		if (!_Endwrite())
			_Ans = 0;
		if (fclose(_Myfile) != 0)
			_Ans = 0;
		}
	_Init(0, _Closefl);
	return (_Ans);
	}

template<class _Elem, class _Traits>
	typename basic_filebuf<_Elem, _Traits>::int_type basic_filebuf<_Elem, _Traits>::overflow(int_type _Meta)
	{	// put an element to stream
	if (_Traits::eq_int_type(_Traits::eof(), _Meta))
		return (_Traits::not_eof(_Meta));	// EOF, return success code
	else if (_Mysb::pptr() != 0
		&& _Mysb::pptr() < _Mysb::epptr())
		{	// room in buffer, store it
		*_Mysb::_Pninc() = _Traits::to_char_type(_Meta);
		return (_Meta);
		}
	else if (_Myfile == 0)
		return (_Traits::eof());	// no open C stream, fail
	else if (_Pcvt == 0)
		return (_Fputc(_Traits::to_char_type(_Meta), _Myfile)
			? _Meta : _Traits::eof());	// no codecvt facet, put as is
	else
		{	// put using codecvt facet
		const int _STRING_INC = 8;
		const _Elem _Ch = _Traits::to_char_type(_Meta);
		const _Elem *_Src;
		char *_Dest;

		string _Str(_STRING_INC, '\0');
		for (; ; )
			switch (_Pcvt->out(_State,
				&_Ch, &_Ch + 1, _Src,
				&*_Str.begin(), &*_Str.begin() + _Str.size(), _Dest))
			{	// test result of converting one element
			case codecvt_base::partial:
			case codecvt_base::ok:
				{	// converted something, try to put it out
				size_t _Count = _Dest - &*_Str.begin();
				if (0 < _Count && _Count !=
					fwrite(&*_Str.begin(), 1, _Count, _Myfile))
					return (_Traits::eof());	// write failed

				_Wrotesome = true;	// write succeeded
				if (_Src != &_Ch)
					return (_Meta);	// converted whole element

				if (0 < _Count)
					;
				else if (_Str.size() < 4 * _STRING_INC)
					_Str.append(_STRING_INC, '\0');	// try with more space
				else
					return (_Traits::eof());	// conversion failed
				break;
				}

			case codecvt_base::noconv:
				return (_Fputc(_Ch, _Myfile) ? _Meta
					: _Traits::eof());	// no conversion, put as is

			default:
				return (_Traits::eof());	// conversion failed
			}
		}
	}

template<class _Elem, class _Traits>
	typename basic_filebuf<_Elem, _Traits>::int_type basic_filebuf<_Elem, _Traits>::pbackfail(int_type _Meta)
	{	// put an element back to stream
	if (_Mysb::gptr() != 0
		&& _Mysb::eback() < _Mysb::gptr()
		&& (_Traits::eq_int_type(_Traits::eof(), _Meta)
		|| _Traits::eq_int_type(_Traits::to_int_type(_Mysb::gptr()[-1]),
			_Meta)))
		{	// just back up position
		_Mysb::_Gndec();
		return (_Traits::not_eof(_Meta));
		}
	else if (_Myfile == 0 || _Traits::eq_int_type(_Traits::eof(), _Meta))
		return (_Traits::eof());	// no open C stream or EOF, fail
	else if (_Pcvt == 0 && _Ungetc(_Traits::to_char_type(_Meta), _Myfile))
		return (_Meta);	// no facet and unget succeeded, return
	else if (_Mysb::gptr() != &_Mychar)
		{	// putback to _Mychar
		_Mychar = _Traits::to_char_type(_Meta);
		_Mysb::setg(&_Mychar, &_Mychar, &_Mychar + 1);
		return (_Meta);
		}
	else
		return (_Traits::eof());	// nowhere to put back
	}

template<class _Elem, class _Traits>
	typename basic_filebuf<_Elem, _Traits>::int_type basic_filebuf<_Elem, _Traits>::underflow()
	{	// get an element from stream, but don't point past it
	int_type _Meta;
	if (_Mysb::gptr() != 0
		&& _Mysb::gptr() < _Mysb::egptr())
		return (_Traits::to_int_type(*_Mysb::gptr()));	// return buffered
	else if (_Traits::eq_int_type(_Traits::eof(), _Meta = uflow()))
		return (_Meta);	// uflow failed, return EOF
	else
		{	// get a char, don't point past it
		pbackfail(_Meta);
		return (_Meta);
		}
	}

template<class _Elem, class _Traits>
	typename basic_filebuf<_Elem, _Traits>::int_type basic_filebuf<_Elem, _Traits>::uflow()
	{	// get an element from stream, point past it
	if (_Mysb::gptr() != 0
		&& _Mysb::gptr() < _Mysb::egptr())
		return (_Traits::to_int_type(
			*_Mysb::_Gninc()));	// return buffered
	else if (_Myfile == 0)
		return (_Traits::eof());	// no open C stream, fail
	else if (_Pcvt == 0)
		{	// no codecvt facet, just get it
		_Elem _Ch = 0;
		return (_Fgetc(_Ch, _Myfile) ? _Traits::to_int_type(_Ch)
			: _Traits::eof());
		}
	else
		{	// build string until codecvt succeeds
		string _Str;

		for (; ; )
			{	// get using codecvt facet
			_Elem _Ch, *_Dest;
			const char *_Src;
			int _Nleft;
			int _Meta = fgetc(_Myfile);

			if (_Meta == EOF)
				return (_Traits::eof());	// partial char?

			_Str.append(1, (char)_Meta);	// append byte and convert
			switch (_Pcvt->in(_State,
				&*_Str.begin(), &*_Str.begin() + _Str.size(), _Src,
				&_Ch, &_Ch + 1, _Dest))
				{	// test result of converting one element
			case codecvt_base::partial:
			case codecvt_base::ok:
				if (_Dest != &_Ch)
					{	// got an element, put back excess and deliver it
					for (_Nleft = &*_Str.begin() + _Str.size() - _Src;
						0 < _Nleft; )
						ungetc(_Src[--_Nleft], _Myfile);
					return (_Traits::to_int_type(_Ch));
					}
				else
					_Str.erase((size_t)0,	// partial, discard used input
						(size_t)(_Src - &*_Str.begin()));
				break;

			case codecvt_base::noconv:
				if (_Str.size() < sizeof (_Elem))
					break;	// no conversion, but need more chars
				memcpy(&_Ch, &*_Str.begin(),
					sizeof (_Elem));	// copy raw bytes to element
				return (_Traits::to_int_type(_Ch));	// return result

			default:
				return (_Traits::eof());	// conversion failed
				}
			}
		}
	}

template<class _Elem, class _Traits>
	typename basic_filebuf<_Elem, _Traits>::pos_type basic_filebuf<_Elem, _Traits>::seekoff(off_type _Off,
	ios_base::seekdir _Way,
	ios_base::openmode)
	{	// change position by _Off
	fpos_t _Fileposition;

	if (_Mysb::egptr() <= _Mysb::gptr()	// nothing buffered
		|| _Mysb::gptr() != &_Mychar	// nothing putback
		|| _Way != ios_base::cur)		// not a relative seek
		;	// don't have to worry about putback character
	else if (_Pcvt == 0)
		_Off -= (off_type)sizeof (_Elem);	// back up over _Elem bytes

	if (_Myfile == 0 || !_Endwrite()
		|| (_Off != 0 || _Way != ios_base::cur)
			&& fseek(_Myfile, (long)_Off, _Way) != 0
		|| fgetpos(_Myfile, &_Fileposition) != 0)
		return (pos_type(_BADOFF));	// report failure
	if (_Mysb::gptr() == &_Mychar)
		_Mysb::setg(&_Mychar, &_Mychar + 1,
			&_Mychar + 1);	// discard any putback
	return (_POS_TYPE_FROM_STATE(pos_type, _State,
		_Fileposition));	// return new position
	}

template<class _Elem, class _Traits>
	typename basic_filebuf<_Elem, _Traits>::pos_type basic_filebuf<_Elem, _Traits>::seekpos(pos_type _Pos,
	ios_base::openmode)
	{	// change position to _Pos
	fpos_t _Fileposition = _POS_TYPE_TO_FPOS_T(_Pos);
	off_type _Off = (off_type)_Pos - _FPOSOFF(_Fileposition);

	if (_Myfile == 0 || !_Endwrite()
		|| fsetpos(_Myfile, &_Fileposition) != 0
		|| _Off != 0 && fseek(_Myfile, (long)_Off, SEEK_CUR) != 0
		|| fgetpos(_Myfile, &_Fileposition) != 0)
		return (pos_type(_BADOFF));	// report failure

	_State = _POS_TYPE_TO_STATE(_Pos);
	if (_Mysb::gptr() == &_Mychar)
		_Mysb::setg(&_Mychar, &_Mychar + 1,
			&_Mychar + 1);	// discard any putback
	return (_POS_TYPE_FROM_STATE(pos_type, _State,
		_Fileposition));	// return new position
	}

template<class _Elem, class _Traits>
	void basic_filebuf<_Elem, _Traits>::_Init(_Filet *_File, _Initfl _Which)
	{	// initialize to C stream _File after {new, open, close}
	static _Myst _Stinit;	// initial state
	_Closef = _Which == _Openfl;
	_Wrotesome = false;

	_Mysb::_Init();	// initialize stream buffer base object

 #if _HAS_DINKUM_CLIB
	if (_File != 0 && sizeof (_Elem) == 1)
		_Mysb::_Init((_Elem **)&_File->_Buf,
			(_Elem **)&_File->_Next,
			(_Elem **)&_File->_Rend,
			(_Elem **)&_File->_Buf,
			(_Elem **)&_File->_Next,
			(_Elem **)&_File->_Wend);
 #endif /* _HAS_DINKUM_CLIB */

 #if _HAS_POINTER_CLIB
	if (_File != 0 && sizeof (_Elem) == 1)
		_Mysb::_Init((_Elem **)&_File->_RBEGIN,
			(_Elem **)&_File->_RNEXT,
			(_Elem **)&_File->_REND,
			(_Elem **)&_File->_WBEGIN,
			(_Elem **)&_File->_WNEXT,
			(_Elem **)&_File->_WEND);
 #endif /* _HAS_POINTER_CLIB */

 #if _HAS_CONVENTIONAL_CLIB
 #ifndef _IORCNT
  #define _IORCNT	_IOCNT	/* read and write counts are the same */
  #define _IOWCNT _IOCNT
 #endif /* _IORCNT */

	if (_File != 0 && sizeof (_Elem) == 1)
		{	// point inside C stream with [first, first + count) buffer
		_Elem **_Pb = (_Elem **)&_File->_IOBASE;
		_Elem **_Pn = (_Elem **)&_File->_IOPTR;
		int *_Nr = (int *)&_File->_IORCNT;
		int *_Nw = (int *)&_File->_IOWCNT;
		_Mysb::_Init(_Pb, _Pn, _Nr, _Pb, _Pn, _Nw);
		}
 #endif /* _HAS_CONVENTIONAL_CLIB */

	_Myfile = _File;
	_State = _Stinit;
	_Pcvt = 0;	// pointer to codecvt facet
	}

template<class _Elem, class _Traits>
	bool basic_filebuf<_Elem, _Traits>::_Endwrite()
	{	// put shift to initial conversion state, as needed
	if (_Pcvt == 0 || !_Wrotesome)
		return (true);
	else
		{	// may have to put
		const int _STRING_INC = 8;
		char *_Dest;
		if (_Traits::eq_int_type(_Traits::eof(), overflow()))
			return (false);

		string _Str(_STRING_INC, '\0');
		for (; ; )
			switch (_Pcvt->unshift(_State,
				&*_Str.begin(), &*_Str.begin() + _Str.size(), _Dest))
			{	// test result of homing conversion
			case codecvt_base::ok:
				_Wrotesome = false;	// homed successfully

			case codecvt_base::partial:	// fall through
				{	// put any generated bytes
				size_t _Count = _Dest - &*_Str.begin();
				if (0 < _Count && _Count !=
					fwrite(&*_Str.begin(), 1, _Count, _Myfile))
					return (false);	// write failed
				if (!_Wrotesome)
					return (true);
				if (_Count == 0)
					_Str.append(_STRING_INC, '\0');	// try with more space
				break;
				}

			case codecvt_base::noconv:
				return (true);	// nothing to do

			default:
				return (false);	// conversion failed
			}
		}
	}

template<class _Elem, class _Traits>
	void basic_filebuf<_Elem, _Traits>::_Initcvt(_Cvt *_Newpcvt)
	{	// initialize codecvt pointer
	if (_Newpcvt->always_noconv())
		_Pcvt = 0;	// nothing to do
	else
		{	// set up for nontrivial codecvt facet
		_Pcvt = _Newpcvt;
		_Mysb::_Init();	// reset any buffering
		}
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
