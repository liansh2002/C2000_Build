// EXPORTED FUNCTIONS
#include <ios>
_STD_BEGIN

template<class _Elem, class _Traits>
	basic_ios<_Elem, _Traits>& basic_ios<_Elem, _Traits>::copyfmt(const _Myt& _Right)
	{	// copy format parameters
	_Tiestr = _Right.tie();
	_Fillch = _Right.fill();
	ios_base::copyfmt(_Right);
	return (*this);
	}

template<class _Elem, class _Traits>
	basic_streambuf<_Elem, _Traits> * basic_ios<_Elem, _Traits>::rdbuf(_Mysb *_Strbuf)
	{	// set stream buffer pointer
	_Mysb *_Oldstrbuf = _Mystrbuf;
	_Mystrbuf = _Strbuf;
	clear();
	return (_Oldstrbuf);
	}

template<class _Elem, class _Traits>
	locale basic_ios<_Elem, _Traits>::imbue(const locale& _Loc)
	{	// set locale to argument
	locale _Oldlocale = ios_base::imbue(_Loc);
	if (rdbuf() != 0)
		rdbuf()->pubimbue(_Loc);
	return (_Oldlocale);
	}

template<class _Elem, class _Traits>
	void basic_ios<_Elem, _Traits>::init(_Mysb *_Strbuf,
	bool _Isstd)
	{	// initialize with stream buffer pointer
	_Init();	// initialize ios_base
	_Mystrbuf = _Strbuf;
	_Tiestr = 0;
	_Fillch = widen(' ');

	if (_Mystrbuf == 0)
		setstate(badbit);

	if (_Isstd)
		_Addstd();	// special handling for standard streams
	else
		_Stdstr = 0;
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
