// EXPORTED FUNCTIONS
#include <vector>
_STD_BEGIN

template<class _Ty, class _Ax>
	vector<_Ty, _Ax>::vector(const _Myt& _Right)
	: _Mybase(_Right._Alval)
	{	// construct by copying _Right
	if (_Buy(_Right.size()))
		_TRY_BEGIN
		_Mylast = _Ucopy(_Right.begin(), _Right.end(), _Myfirst);
		_CATCH_ALL
		_Tidy();
		_RERAISE;
		_CATCH_END
	}

template<class _Ty, class _Ax>
	template<class _Iter>
	void vector<_Ty, _Ax>::_Construct(_Iter _First,
		_Iter _Last, input_iterator_tag)
	{	// initialize with [_First, _Last), input iterators
	_Buy(0);
	_TRY_BEGIN
	insert(begin(), _First, _Last);
	_CATCH_ALL
	_Tidy();
	_RERAISE;
	_CATCH_END
	}

template<class _Ty, class _Ax>
	void vector<_Ty, _Ax>::_Construct_n(size_type _Count, const _Ty& _Val)
	{	// construct from _Count * _Val
	if (_Buy(_Count))
		{	// nonzero, fill it
		_TRY_BEGIN
		_Mylast = _Ufill(_Myfirst, _Count, _Val);
		_CATCH_ALL
		_Tidy();
		_RERAISE;
		_CATCH_END
		}
	}

template<class _Ty, class _Ax>
	vector<_Ty, _Ax>& vector<_Ty, _Ax>::operator=(const _Myt& _Right)
	{	// assign _Right
	if (this != &_Right)
		{	// worth doing

 #if _HAS_ITERATOR_DEBUGGING
		this->_Orphan_all();
 #endif /* _HAS_ITERATOR_DEBUGGING */

		if (_Right.size() == 0)
			clear();	// new sequence empty, free storage
		else if (_Right.size() <= size())
			{	// enough elements, copy new and destroy old
			pointer _Ptr = copy(_Right._Myfirst, _Right._Mylast,
				_Myfirst);	// copy new
			_Destroy(_Ptr, _Mylast);	// destroy old
			_Mylast = _Myfirst + _Right.size();
			}
		else if (_Right.size() <= capacity())
			{	// enough room, copy and construct new
			pointer _Ptr = _Right._Myfirst + size();
			copy(_Right._Myfirst, _Ptr, _Myfirst);
			_Mylast = _Ucopy(_Ptr, _Right._Mylast, _Mylast);
			}
		else
			{	// not enough room, allocate new array and construct new
			if (_Myfirst != 0)
				{	// discard old array
				_Destroy(_Myfirst, _Mylast);
				this->_Alval.deallocate(_Myfirst, _Myend - _Myfirst);
				}
			if (_Buy(_Right.size()))
				_Mylast = _Ucopy(_Right._Myfirst, _Right._Mylast,
					_Myfirst);
			}
		}
	return (*this);
	}

template<class _Ty, class _Ax>
	void vector<_Ty, _Ax>::reserve(size_type _Count)
	{	// determine new minimum length of allocated storage
	if (max_size() < _Count)
		_Xlen();	// result too long
	else if (capacity() < _Count)
		{	// not enough room, reallocate
		pointer _Ptr = this->_Alval.allocate(_Count);

		_TRY_BEGIN
		_Ucopy(begin(), end(), _Ptr);
		_CATCH_ALL
		this->_Alval.deallocate(_Ptr, _Count);
		_RERAISE;
		_CATCH_END

		size_type _Size = size();
		if (_Myfirst != 0)
			{	// destroy and deallocate old array
			_Destroy(_Myfirst, _Mylast);
			this->_Alval.deallocate(_Myfirst, _Myend - _Myfirst);
			}

 #if _HAS_ITERATOR_DEBUGGING
		this->_Orphan_all();
 #endif /* _HAS_ITERATOR_DEBUGGING */

		_Myend = _Ptr + _Count;
		_Mylast = _Ptr + _Size;
		_Myfirst = _Ptr;
		}
	}

template<class _Ty, class _Ax>
	template<class _Iter>
	void vector<_Ty, _Ax>::_Insert(iterator _Where,
		_Iter _First, _Iter _Last, forward_iterator_tag)
	{	// insert [_First, _Last) at _Where, forward iterators

 #if _HAS_ITERATOR_DEBUGGING
	if (_Where._Mycont != this
		|| _Where._Myptr < _Myfirst || _Mylast < _Where._Myptr)
		_DEBUG_ERROR("vector insert iterator outside range");
	_DEBUG_RANGE(_First, _Last);
	if (_Debug_get_cont(_First) == this)
		_DEBUG_ERROR("vector insertion overlaps range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	size_type _Count = 0;
	_Distance(_First, _Last, _Count);
	size_type _Capacity = capacity();

	if (_Count == 0)
		;
	else if (max_size() - size() < _Count)
		_Xlen();	// result too long
	else if (_Capacity < size() + _Count)
		{	// not enough room, reallocate
		_Capacity = max_size() - _Capacity / 2 < _Capacity
			? 0 : _Capacity + _Capacity / 2;	// try to grow by 50%
		if (_Capacity < size() + _Count)
			_Capacity = size() + _Count;
		pointer _Newvec = this->_Alval.allocate(_Capacity);
		pointer _Ptr = _Newvec;

		_TRY_BEGIN
		_Ptr = _Ucopy(_Myfirst, _VEC_ITER_BASE(_Where),
			_Newvec);	// copy prefix
		_Ptr = _Ucopy(_First, _Last, _Ptr);	// add new stuff
		_Ucopy(_VEC_ITER_BASE(_Where), _Mylast, _Ptr);	// copy suffix
		_CATCH_ALL
		_Destroy(_Newvec, _Ptr);
		this->_Alval.deallocate(_Newvec, _Capacity);
		_RERAISE;
		_CATCH_END

		_Count += size();
		if (_Myfirst != 0)
			{	// destroy and deallocate old array
			_Destroy(_Myfirst, _Mylast);
			this->_Alval.deallocate(_Myfirst, _Myend - _Myfirst);
			}

 #if _HAS_ITERATOR_DEBUGGING
		this->_Orphan_all();
 #endif /* _HAS_ITERATOR_DEBUGGING */

		_Myend = _Newvec + _Capacity;
		_Mylast = _Newvec + _Count;
		_Myfirst = _Newvec;
		}
	else if ((size_type)(end() - _Where) < _Count)
		{	// new stuff spills off end
		_Ucopy(_VEC_ITER_BASE(_Where), _Mylast,
			_VEC_ITER_BASE(_Where) + _Count);	// copy suffix
		_Iter _Mid = _First;
		advance(_Mid, end() - _Where);

		_TRY_BEGIN
		_Ucopy(_Mid, _Last, _Mylast);	// insert new stuff off end
		_CATCH_ALL
		_Destroy(_VEC_ITER_BASE(_Where) + _Count, _Mylast + _Count);
		_RERAISE;
		_CATCH_END

		_Mylast += _Count;

 #if _HAS_ITERATOR_DEBUGGING
		_Orphan_range(_Where._Myptr, _Mylast);
 #endif /* _HAS_ITERATOR_DEBUGGING */

		copy(_First, _Mid,
			_VEC_ITER_BASE(_Where));	// insert to old end
		}
	else
		{	// new stuff can all be assigned
		pointer _Oldend = _Mylast;
		_Mylast = _Ucopy(_Oldend - _Count, _Oldend,
			_Mylast);	// copy suffix
		copy_backward(_VEC_ITER_BASE(_Where), _Oldend - _Count,
			_Oldend);	// copy hole

 #if _HAS_ITERATOR_DEBUGGING
		_Orphan_range(_Where._Myptr, _Mylast);
 #endif /* _HAS_ITERATOR_DEBUGGING */

		copy(_First, _Last,
			_VEC_ITER_BASE(_Where));	// insert into hole
		}
	}

template<class _Ty, class _Ax>
	typename vector<_Ty, _Ax>::iterator vector<_Ty, _Ax>::erase(iterator _First, iterator _Last)
	{	// erase [_First, _Last)
	if (_First != _Last)
		{	// worth doing, copy down over hole

 #if _HAS_ITERATOR_DEBUGGING
		if (_Last < _First || _First._Mycont != this
			|| _First._Myptr < _Myfirst || _Mylast < _Last._Myptr)
			_DEBUG_ERROR("vector erase iterator outside range");
		pointer _Ptr = copy(_VEC_ITER_BASE(_Last), _Mylast,
			_VEC_ITER_BASE(_First));
		_Orphan_range(_First._Myptr, _Mylast);

 #else /* _HAS_ITERATOR_DEBUGGING */
		pointer _Ptr = copy(_VEC_ITER_BASE(_Last), _Mylast,
			_VEC_ITER_BASE(_First));
 #endif /* _HAS_ITERATOR_DEBUGGING */

		_Destroy(_Ptr, _Mylast);
		_Mylast = _Ptr;
		}
	return (_First);
	}

template<class _Ty, class _Ax>
	bool vector<_Ty, _Ax>::_Buy(size_type _Capacity)
	{	// allocate array with _Capacity elements
	_Myfirst = 0, _Mylast = 0, _Myend = 0;
	if (_Capacity == 0)
		return (false);
	else if (max_size() < _Capacity)
		_Xlen();	// result too long
	else
		{	// nonempty array, allocate storage
		_Myfirst = this->_Alval.allocate(_Capacity);
		_Mylast = _Myfirst;
		_Myend = _Myfirst + _Capacity;
		}
	return (true);
	}

template<class _Ty, class _Ax>
	void vector<_Ty, _Ax>::_Insert_n(iterator _Where,
	size_type _Count, const _Ty& _Val)
	{	// insert _Count * _Val at _Where

 #if _HAS_ITERATOR_DEBUGGING
	if (_Where._Mycont != this
		|| _Where._Myptr < _Myfirst || _Mylast < _Where._Myptr)
		_DEBUG_ERROR("vector insert iterator outside range");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	_Ty _Tmp = _Val;	// in case _Val is in sequence
	size_type _Capacity = capacity();

	if (_Count == 0)
		;
	else if (max_size() - size() < _Count)
		_Xlen();	// result too long
	else if (_Capacity < size() + _Count)
		{	// not enough room, reallocate
		_Capacity = max_size() - _Capacity / 2 < _Capacity
			? 0 : _Capacity + _Capacity / 2;	// try to grow by 50%
		if (_Capacity < size() + _Count)
			_Capacity = size() + _Count;
		pointer _Newvec = this->_Alval.allocate(_Capacity);
		pointer _Ptr = _Newvec;

		_TRY_BEGIN
		_Ptr = _Ucopy(_Myfirst, _VEC_ITER_BASE(_Where),
			_Newvec);	// copy prefix
		_Ptr = _Ufill(_Ptr, _Count, _Tmp);	// add new stuff
		_Ucopy(_VEC_ITER_BASE(_Where), _Mylast, _Ptr);	// copy suffix
		_CATCH_ALL
		_Destroy(_Newvec, _Ptr);
		this->_Alval.deallocate(_Newvec, _Capacity);
		_RERAISE;
		_CATCH_END

		_Count += size();
		if (_Myfirst != 0)
			{	// destroy and deallocate old array
			_Destroy(_Myfirst, _Mylast);
			this->_Alval.deallocate(_Myfirst, _Myend - _Myfirst);
			}

 #if _HAS_ITERATOR_DEBUGGING
		this->_Orphan_all();
 #endif /* _HAS_ITERATOR_DEBUGGING */

		_Myend = _Newvec + _Capacity;
		_Mylast = _Newvec + _Count;
		_Myfirst = _Newvec;
		}
	else if ((size_type)(_Mylast - _VEC_ITER_BASE(_Where)) < _Count)
		{	// new stuff spills off end
		_Ucopy(_VEC_ITER_BASE(_Where), _Mylast,
			_VEC_ITER_BASE(_Where) + _Count);	// copy suffix

		_TRY_BEGIN
		_Ufill(_Mylast, _Count - (_Mylast - _VEC_ITER_BASE(_Where)),
			_Tmp);	// insert new stuff off end
		_CATCH_ALL
		_Destroy(_VEC_ITER_BASE(_Where) + _Count, _Mylast + _Count);
		_RERAISE;
		_CATCH_END

		_Mylast += _Count;

 #if _HAS_ITERATOR_DEBUGGING
		_Orphan_range(_Where._Myptr, _Mylast);
 #endif /* _HAS_ITERATOR_DEBUGGING */

		fill(_VEC_ITER_BASE(_Where), _Mylast - _Count,
			_Tmp);	// insert up to old end
		}
	else
		{	// new stuff can all be assigned
		pointer _Oldend = _Mylast;
		_Mylast = _Ucopy(_Oldend - _Count, _Oldend,
			_Mylast);	// copy suffix

 #if _HAS_ITERATOR_DEBUGGING
		_Orphan_range(_Where._Myptr, _Mylast);
 #endif /* _HAS_ITERATOR_DEBUGGING */

		copy_backward(_VEC_ITER_BASE(_Where), _Oldend - _Count,
			_Oldend);	// copy hole
		fill(_VEC_ITER_BASE(_Where), _VEC_ITER_BASE(_Where) + _Count,
			_Tmp);	// insert into hole
		}
	}

template<class _Alloc>
	void vector<_Bool, _Alloc>::flip()
	{	// toggle all elements
	for (typename _Vbtype::iterator _Next = _Myvec.begin();
		_Next != _Myvec.end(); ++_Next)
		*_Next = (_Vbase)~*_Next;
	_Trim(_Mysize);
	}

template<class _Alloc>
	vector<_Bool, _Alloc>::size_type vector<_Bool, _Alloc>::_Insert_x(iterator _Where, size_type _Count)
	{	// make room to insert _Count elements at _Where
	size_type _Off = _Where - begin();

 #if _HAS_ITERATOR_DEBUGGING
	if (end() < _Where)
		_DEBUG_ERROR("vector<bool> insert iterator outside range");
	bool _Realloc = capacity() - size() < _Count;
 #endif /* _HAS_ITERATOR_DEBUGGING */

	if (_Count == 0)
		;
	else if (max_size() - size() < _Count)
		_Xlen();	// result too long
	else
		{	// worth doing
		_Myvec.resize(_Nw(size() + _Count), 0);
		if (size() == 0)
			_Mysize += _Count;
		else
			{	// make room and copy down suffix
			iterator _Oldend = end();
			_Mysize += _Count;
			copy_backward(begin() + _Off, _Oldend, end());
			}

 #if _HAS_ITERATOR_DEBUGGING
		_Orphan_range(_Realloc ? 0 : _Off, _Mysize);
 #endif /* _HAS_ITERATOR_DEBUGGING */

		}
	return (_Off);
	}

template<class _Alloc>
	void vector<_Bool, _Alloc>::_Trim(size_type _Size)
	{	// trim base vector to exact length in bits
	if (max_size() < _Size)
		_Xlen();	// result too long
	size_type _Words = _Nw(_Size);

	if (_Words < _Myvec.size())
		_Myvec.erase(_Myvec.begin() + _Words, _Myvec.end());
	_Mysize = _Size;
	_Size %= _VBITS;
	if (0 < _Size)
		_Myvec[_Words - 1] &= (_Vbase)((1 << _Size) - 1);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
