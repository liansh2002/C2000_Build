// EXPORTED FUNCTIONS
#include <xlocale>
_STD_BEGIN

/* template member of non-template class */
	template<class _Facet>
	locale locale::combine(const locale& _Loc) const
	{	// combine two locales
	_Facet *_Facptr;

	_TRY_BEGIN
		_Facptr = (_Facet *)&_STD use_facet<_Facet>(_Loc);
	_CATCH_ALL
		_THROW(runtime_error, "locale::combine facet missing");
	_CATCH_END

	_Locimp *_Newimp = _NEW_CRT _Locimp(*_Ptr);
	_Newimp->_Addfac(_Facptr, _Facet::id);

 #if _HAS_STRICT_CONFORMANCE
	_Newimp->_Catmask = 0;
	_Newimp->_Name = "*";

 #else /* _HAS_STRICT_CONFORMANCE */
	if (_Facet::_Getcat() != (size_t)(-1))
		{	// not a standard facet, result has no name
		_Newimp->_Catmask = 0;
		_Newimp->_Name = "*";
		}
 #endif /* _HAS_STRICT_CONFORMANCE */

	return (locale(_Newimp));
	}

/* template member of non-template class */
	template<class _Facet>
	locale::locale(const locale& _Loc, _Facet *_Facptr)
		: _Ptr(_NEW_CRT _Locimp(*_Loc._Ptr))
	{	// construct from _Loc, replacing facet with *_Facptr
	if (_Facptr != 0)
		{	// replace facet
		_Ptr->_Addfac(_Facptr, _Facet::id);
		if (_Facet::_Getcat() != (size_t)(-1))
			_Ptr->_Catmask = 0, _Ptr->_Name = "*";	// no C category
		}
	}

template<class _Facet>
	const _Facet& use_facet(const locale& _Loc)
	{	// get facet reference from locale
	_Lockit _Lock(_LOCK_LOCALE);	// the thread lock, make get atomic
	const locale::facet *_Psave =
		_Facetptr<_Facet>::_Psave;	// static pointer to lazy facet

	size_t _Id = _Facet::id;
	const locale::facet *_Pf = _Loc._Getfacet(_Id);

	if (_Pf != 0)
		;	// got facet from locale
	else if (_Psave != 0)
		_Pf = _Psave;	// lazy facet already allocated
	else if (_Facet::_Getcat(&_Psave) == (size_t)(-1))

 #if _HAS_EXCEPTIONS
		throw bad_cast();	// lazy disallowed

 #else /* _HAS_EXCEPTIONS */
		abort();	// lazy disallowed
 #endif /* _HAS_EXCEPTIONS */

	else
		{	// queue up lazy facet for destruction
		_Pf = _Psave;
		_Facetptr<_Facet>::_Psave = _Psave;

		locale::facet *_Pfmod = (_Facet *)_Psave;
		_Pfmod->_Incref();
		_Pfmod->_Register();
		}

	return ((const _Facet&)(*_Pf));	// should be dynamic_cast
	}

template<class _Elem,
	class _InIt>
	int _Getloctxt(_InIt& _First, _InIt& _Last, size_t _Numfields,
		const _Elem *_Ptr)
	{	// find field at _Ptr that matches longest in [_First, _Last)
	for (size_t _Off = 0; _Ptr[_Off] != (_Elem)0; ++_Off)
		if (_Ptr[_Off] == _Ptr[0])
			++_Numfields;	// add fields with leading mark to initial count
	string _Str(_Numfields, '\0');	// one column counter for each field

	int _Ans = -2;	// no candidates so far
	for (size_t _Column = 1; ; ++_Column, ++_First, _Ans = -1)
		{	// test each element against all viable fields
		bool  _Prefix = false;	// seen at least one valid prefix
		size_t _Off = 0;	// offset into fields
		size_t _Field = 0;	// current field number

		for (; _Field < _Numfields; ++_Field)
			{	// test element at _Column in field _Field
			for (; _Ptr[_Off] != (_Elem)0 && _Ptr[_Off] != _Ptr[0]; ++_Off)
				;	// find beginning of field

			if (_Str[_Field] != '\0')
				_Off += _Str[_Field];	// skip tested columns in field
			else if (_Ptr[_Off += _Column] == _Ptr[0]
				|| _Ptr[_Off] == (_Elem)0)
				{	// matched all of field, save as possible answer
				_Str[_Field] = (char)(_Column < 127
					? _Column : 127);	// save skip count if small enough
				_Ans = (int)_Field;	// save answer
				}
			else if (_First == _Last || _Ptr[_Off] != *_First)
				_Str[_Field] = (char)(_Column < 127
					? _Column : 127);	// no match, just save skip count
			else
				_Prefix = true;	// still a valid prefix
			}

		if (!_Prefix || _First == _Last)
			break;	// no pending prefixes or no input, give up
		}
	return (_Ans);	// return field number or negative value on failure
	}

template<class _Elem>
	_Elem *_Maklocstr(const char *_Ptr, _Elem *,
		const _Locinfo::_Cvtvec&)
	{	// convert C string to _Elem sequence using _Cvtvec
	size_t _Count = _CSTD strlen(_Ptr) + 1;
	_Elem *_Ptrdest = _NEW_CRT _Elem[_Count];

	for (_Elem *_Ptrnext = _Ptrdest; 0 < _Count; --_Count, ++_Ptrnext, ++_Ptr)
		*_Ptrnext = (_Elem)(unsigned char)*_Ptr;
	return (_Ptrdest);
	}

template<class _Elem>
	const _Elem *ctype<_Elem>::do_scan_is(mask _Maskval,
	const _Elem *_First, const _Elem *_Last) const
	{	// find first in [_First, _Last) that fits mask classification
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last && !is(_Maskval, *_First); ++_First)
		;
	return (_First);
	}

template<class _Elem>
	const _Elem *ctype<_Elem>::do_scan_not(mask _Maskval,
	const _Elem *_First, const _Elem *_Last) const
	{	// find first in [_First, _Last) not fitting mask classification
	_DEBUG_RANGE(_First, _Last);
	for (; _First != _Last && is(_Maskval, *_First); ++_First)
		;
	return (_First);
	}

template<class _Elem>
	const _Elem *ctype<_Elem>::do_tolower(_Elem *_First, const _Elem *_Last) const
	{	// convert [_First, _Last) in place to lower case
	_DEBUG_RANGE((const _Elem *)_First, _Last);
	for (; _First != _Last; ++_First)
		{	// convert *_First to lower case
		unsigned char _Byte = (unsigned char)narrow(*_First, '\0');
		if (_Byte != '\0')
			*_First = (widen((char)_Tolower(_Byte, &_Ctype)));
		}
	return ((const _Elem *)_First);
	}

template<class _Elem>
	const _Elem *ctype<_Elem>::do_toupper(_Elem *_First, const _Elem *_Last) const
	{	// convert [_First, _Last) in place to upper case
	_DEBUG_RANGE((const _Elem *)_First, _Last);
	for (; _First != _Last; ++_First)
		{	// convert *_First to upper case
		unsigned char _Byte = (unsigned char)narrow(*_First, '\0');
		if (_Byte != '\0')
			*_First = (widen((char)_Toupper(_Byte, &_Ctype)));
		}
	return ((const _Elem *)_First);
	}

template<class _Elem>
	const char *ctype<_Elem>::do_widen(const char *_First,
	const char *_Last, _Elem *_Dest) const
	{	// widen chars in [_First, _Last)
	_DEBUG_RANGE(_First, _Last);
	_DEBUG_POINTER(_Dest);
	for (; _First != _Last; ++_First, ++_Dest)
		*_Dest = _MAKLOCCHR(_Elem, *_First, _Cvt);
	return (_First);
	}

template<class _Elem>
	const _Elem *ctype<_Elem>::do_narrow(const _Elem *_First,
	const _Elem *_Last, char _Dflt, char *_Dest) const
	{	// narrow elements in [_First, _Last) to chars
	_DEBUG_RANGE(_First, _Last);
	_DEBUG_POINTER(_Dest);
	for (; _First != _Last; ++_First, ++_Dest)
		*_Dest = _Donarrow(*_First, _Dflt);
	return (_First);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
