// delaop -- operator delete[](void *) REPLACEABLE
#include <xstddef>

void operator delete[](void *ptr) _THROW0()
	{	// free an allocated object
	operator delete(ptr);
	}

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
