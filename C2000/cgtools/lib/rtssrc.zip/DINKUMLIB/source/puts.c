/* puts function */
#include "xstdio.h"
_STD_BEGIN

int (puts)(const char *s)
	{	/*	put string + newline to stdout */
	int ans;
#if defined(__FPUTS_RETURN_NUM_BYTES__)
	int num_of_bytes;
#endif /* defined(__FPUTS_RETURN_NUM_BYTES__) */
	_Lockfileatomic(stdout);
#if defined(__FPUTS_RETURN_NUM_BYTES__)
	num_of_bytes = fputs(s, stdout);
	ans = num_of_bytes < 0 || fputc('\n', stdout) < 0 ? EOF : num_of_bytes + 1;
#else
	ans = fputs(s, stdout) < 0 || fputc('\n', stdout) < 0 ? EOF : 0;
#endif /* defined(__FPUTS_RETURN_NUM_BYTES__) */
	_Unlockfileatomic(stdout);
	return (ans);
	}
_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
