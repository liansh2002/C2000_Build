/* strncat function */
#if defined(__TI_COMPILER_VERSION__)
#undef  _INLINE
#define _STRING_IMPLEMENTATION
#define _STRNCAT
#include <string.h>
#else /* defined(__TI_COMPILER_VERSION__) */
#include <string.h>
_STD_BEGIN

char *(strncat)(char *_Restrict s1, const char *_Restrict s2, size_t n)
	{	/* copy char s2[max n] to end of s1[] */
	char *s;

	for (s = s1; *s != '\0'; ++s)
		;	/* find end of s1[] */
	for (; 0 < n && *s2 != '\0'; --n)
		*s++ = *s2++;	/* copy at most n chars from s2[] */
	*s = '\0';
	return (s1);
	}
_STD_END
#endif /* defined(__TI_COMPILER_VERSION__) */
/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
