/* strrchr function */
#if defined(__TI_COMPILER_VERSION__)
#undef  _INLINE
#define _STRING_IMPLEMENTATION
#define _STRRCHR
#include <string.h>
#else /* defined(__TI_COMPILER_VERSION__) */
#include <string.h>
_STD_BEGIN

_Const_return char *(strrchr)(const char *s, int c)
	{	/* find last occurrence of c in char s[] */
	const char ch = (char)c;
	const char *sc;

	for (sc = 0; ; ++s)
		{	/* check another char */
		if (*s == ch)
			sc = s;
		if (*s == '\0')
			return ((char *)sc);
		}
	}
_STD_END
#endif /* defined(__TI_COMPILER_VERSION__) */
/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
